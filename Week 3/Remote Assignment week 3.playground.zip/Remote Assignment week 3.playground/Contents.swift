//: ## 1.
/*:
 ### Closure:
 closures are self-contained blocks of functionality that can be passed around and used in your code, without creating a named function.

 ### Execute a closure:
- Closures can be passed as arguments to functions, stored in variables or properties, and used in various contexts where functions are expected (such as map, reduce, sorting...)
- Note that parameter names are only used in the body, and cannot add different argument label. Default for parameter is also unavailable.
 */
//for example: the closure is assigned to variable addClosure with two Int parameter a, b
var addClosure: (Int, Int) -> Int = { (a, b) in
    return a + b
}

//call the closure
let result = addClosure(7, 3)

//: ## 2.
var isOddClosure: (Int) -> Bool = { (input) in
    return input % 2 != 0
}

isOddClosure(3)
isOddClosure(6)

//: ## 3.
func printTriangle(layers: Int) { 
    for i in 1...layers {
        for j in 1...i {
            print("*", terminator: "")
        }
        print()
    }
}

printTriangle(layers: 5)

